### Task 12: Stock workspace/toolbar/summary/filters (F04/F08)

**Files:** StockView.vue; createStockToolbar.vue,StockSummary.vue; tests`adaptiveStockWorkspace.test.js`

- [ ] Testsearch/role/category/archiveapply/cancel/reset; actionsเปิดmodalเดิมถูกID; zero/emptyมีrecovery
- [ ] Desktoptoolbar/tablefull; tabletiPadessentialcolumns; phoneรับเข้า/ตรวจนับ+moremenuไม่ล้น
- [ ] Summarycopyตามbackorderruleจริง; titleไม่ซ้ำสองหัวใหญ่; labelsอ่านง่ายไม่แตกแนวตั้ง
- [ ] Filterไม่มีcalendar; filterdraftแยกactive; countsตรงstoreไม่รวมarchiveโดยเผลอ
- [ ] Runworkspace+stockForms; browser320pageoverflow0; commit

