### Task 9: CartPanel/cartreviewdrawer

**Files:** createCartPanel.vue,CartReviewBar.vue; modifyPosView.vue; tests`adaptiveCart.test.js`

**Interface:** Panelbindstore.cart/note/payment/summaryหนึ่งแห่ง; emitscheckout/switchlot; reviewbar`{quantity,subtotal}`emitsopen

- [ ] Testqty/addons/note/payment/remove/close/resizepersist; oneCartPanelmounted; qty2+3แสดง5ไม่ใช่2rows
- [ ] Splitcartเมื่อcontainer≥696pxที่confirmed; ต่ำกว่านั้นdrawerกับsummarybar; desktop/iPadคงdetailworkflow
- [ ] Subtotalเป็นยอดลูกค้าจ่าย; GP/net/COGSรายละเอียดรองมีชื่อถูก; noautoclearontoggle
- [ ] Reservebarspace/safeareasและscrollbody/footer; overlaystacktask4
- [ ] Runadaptivecart+posregressions; commit

