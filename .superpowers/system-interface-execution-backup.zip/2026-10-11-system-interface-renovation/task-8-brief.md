### Task 8: Adaptive product catalog

**Files:** PosView.vue; create`components/pos/PosCatalog.vue`,`PosMenuCard.vue`; tests`adaptivePosCatalog.test.js`

**Interface:** card`{menu,price,outOfStock}`emits`select(menuId)`; catalogsourcefilteredMenus/handlerเดิม

- [ ] Testplatformchange/prices/inactive/empty/search/category; soldoutยังselectableตามbusinessrule
- [ ] Gridใช้containerwidth/cardminimum160px; channel/searchแยกcontext; iPadtouchcatalogอ่านชื่อได้
- [ ] Phoneprimaryfieldsและsinglepagescroll; ไม่มีnestedfixedheightที่บีบcatalogเมื่อตะกร้าโต
- [ ] PricefallbackในPOSยังเดิม; ไม่ใช้adminmissingpriceformatterมาเปลี่ยนrules
- [ ] Runadaptivecatalog+checkouttests; browseriPadportrait/landscapeและphone; commit

