import fs from 'node:fs'
import {parse as parseSfc} from '@vue/compiler-sfc'
import {parse} from '@vue/compiler-dom'
for(const [name,title] of [['MenuEditModal','ข้อมูลเมนู']]){
 const file='src/components/modals/'+name+'.vue';let text=fs.readFileSync(file,'utf8').replace(/\r\n/g,'\n');const source=parseSfc(text).descriptor.template.content,root=parse(source).children.find(n=>n.type===1),nodes=root.children.find(n=>n.type===1).children.filter(n=>n.type===1);
 const html=n=>source.slice(n.loc.start.offset,n.loc.end.offset),clean=value=>value.replace(/class="([^"]*)"/,(full,classes)=>'class="'+classes.split(/\s+/).filter(c=>!(/^(?:p|px|py|pt|pb)-\d/.test(c)||/^border(?:-|$)/.test(c)||/^max-h-/.test(c)||c==='overflow-y-auto'||c==='shrink-0'||c==='flex-1'||/^sm:px-/.test(c))).join(' ')+'"');
 const header=clean(html(nodes[0])).replace(/<button\b[^>]*aria-label="ปิดหน้าต่าง"[^>]*>[\s\S]*?<\/button>/,'');const body=nodes.slice(1,-1).map(n=>clean(html(n))).join('\n'),footer=clean(html(nodes.at(-1)));
 const open=root.props.find(p=>p.type===7&&p.name==='bind'&&p.arg?.content==='open').exp.content,close=root.props.find(p=>p.type===7&&p.name==='on'&&p.arg?.content==='request-close').exp.content;
 const template=`<template>\n <DialogFrame :open="${open}" id="${name}" title="${title}" :teleport="false" @request-close="${close}">\n <template #header>${header}</template>\n ${body}\n <template #footer>${footer}</template>\n </DialogFrame>\n</template>`;
 text=text.replace(/<template>[\s\S]*?<\/template>(?=\s*<script setup>)/,template).replace("import ModalShell from '@/components/ui/ModalShell.vue'","import DialogFrame from '@/components/ui/DialogFrame.vue'");text=text.replace(/\{ X, /,'{ ');
 fs.writeFileSync(file,text);
}
