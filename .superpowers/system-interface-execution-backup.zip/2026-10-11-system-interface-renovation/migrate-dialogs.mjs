import fs from 'node:fs'
import {parse as parseSfc} from '@vue/compiler-sfc'
import {parse} from '@vue/compiler-dom'
const targets=process.argv.slice(2)
for(const name of targets){
 const file='src/components/modals/'+name+'.vue'
 let text=fs.readFileSync(file,'utf8').replace(/\r\n/g,'\n')
 const descriptor=parseSfc(text).descriptor,source=descriptor.template.content
 const root=parse(source).children.find(n=>n.type===1)
 if(root.tag!=='ModalShell')throw new Error('Expected ModalShell '+name)
 const container=root.children.find(n=>n.type===1)
 const nodes=container.children.filter(n=>n.type===1)
 const html=n=>source.slice(n.loc.start.offset,n.loc.end.offset)
 const clean=value=>value.replace(/class="([^"]*)"/,(full,classes)=>'class="'+classes.split(/\s+/).filter(c=>!(/^(?:p|px|py|pt|pb)-\d/.test(c)||/^border(?:-|$)/.test(c)||/^max-h-/.test(c)||c==='overflow-y-auto'||c==='shrink-0'||c==='flex-1')).join(' ')+'"')
 let header=clean(html(nodes[0])).replace(/<button\b[^>]*aria-label="ปิดหน้าต่าง"[^>]*>[\s\S]*?<\/button>/,'')
 let body=nodes.slice(1,-1).map(n=>clean(html(n))).join('\n')
 let footer=clean(html(nodes.at(-1)))
 const open=root.props.find(p=>p.type===7&&p.name==='bind'&&p.arg?.content==='open')?.exp.content
 const close=root.props.find(p=>p.type===7&&p.name==='on'&&p.arg?.content==='request-close')?.exp.content
 if(!open||!close)throw new Error('Missing contract '+name)
 if(name==='CustomOrderModal'){
  footer=footer.replace(/class="[^"]*"/,'class="custom-order-footer"')
  footer=footer.replace('class="flex items-center gap-3"','class="custom-order-footer-actions"')
  footer=footer.replace('@click="qty = Math.max(1, qty - 1)"','aria-label="ลดจำนวนชาม" @click="qty = Math.max(1, qty - 1)"').replace('@click="qty += 1"','aria-label="เพิ่มจำนวนชาม" @click="qty += 1"')
  footer=footer.replace(/>\s*-\s*<\/button>/,'><Minus :size="18" aria-hidden="true"/></button>').replace(/>\s*\+\s*<\/button>/,'><Plus :size="18" aria-hidden="true"/></button>')
  body=body.replaceAll('bg-purple-50/80 border-purple-300 text-purple-950','bg-brand-50 border-brand-200 text-brand-900').replaceAll('text-[10px]','text-[11px]')
 }
 if(name==='LowStockWarningModal'){
  header=header.replace(/\{\{ store.modals.lowStockWarning.isOutOfStock \? '🚨' : '⚠️' \}\}/,'<AlertTriangle :size="22" aria-hidden="true"/>')
  footer=footer.replace('@click="cancel"','data-decision-cancel @click="cancel"')
 }
 if(name==='LotDepletionModal'){
  header=header.replace('<span>⚠️</span>','<AlertTriangle :size="22" aria-hidden="true"/>')
  footer=footer.replace('@click="onCancel"','data-decision-cancel @click="onCancel"')
 }
 if(name==='ReceiptModal')header=''
 let template='<template>\n <DialogFrame :open="'+open+'" id="'+name+'" title="'+(name==='CustomOrderModal'?'ปรับแต่งชาม':name==='LowStockWarningModal'?'ตรวจสอบสต็อก':'เปลี่ยนล็อตวัตถุดิบ')+'" :teleport="false"'+(name==='CustomOrderModal'?'':' initial-focus="[data-decision-cancel]"')+' @request-close="'+close+'">\n  <template #header>'+header+'</template>\n  '+body+'\n  <template #footer>'+footer+'</template>\n </DialogFrame>\n</template>'
 if(name==='ReceiptModal')template=template.replace('title="เปลี่ยนล็อตวัตถุดิบ"','title="ใบเสร็จรับเงิน" width="400px"').replace(' initial-focus="[data-decision-cancel]"','').replace('  <template #header></template>','')
 text=text.replace(/<template>[\s\S]*?<\/template>(?=\s*<script setup>)/,template)
 text=text.replace("import ModalShell from '@/components/ui/ModalShell.vue'","import DialogFrame from '@/components/ui/DialogFrame.vue'")
 if(name==='CustomOrderModal')text=text.replace('import { X, Check, ShoppingBag }','import { Minus, Plus, Check, ShoppingBag }')
 else if(name!=='ReceiptModal')text=text.replace('<script setup>',"<script setup>\nimport {AlertTriangle} from 'lucide-vue-next'")
 if(name==='ReceiptModal')text=text.replace('import { X, Printer }','import { Printer }')
 fs.writeFileSync(file,text)
}
