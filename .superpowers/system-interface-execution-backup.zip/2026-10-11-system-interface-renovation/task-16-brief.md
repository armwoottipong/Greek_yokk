### Task 16: History/archive/permanentdeleteและdangerpatterns

**Files:** StockView.vue,ActivityLogModal.vue,HistoryLogEntry.vue,ConfirmModal.vue; tests`inventoryDangerFlows.test.js`

- [ ] Testarchive/restore/deleteusagewarning/cancel, correctmaterialID, callbackonce, historyclear/exportfilters
- [ ] Migratepermanentdeleteให้dialogfocusinert/escapeถูก; keeparchivealternativeและbusinesslimitations
- [ ] Dangerlabel/impactชัด, nohiddenactionbehindscrollwithoutcue; nativedetailsสำหรับhistoryยังกดด้วยkeyboardได้
- [ ] ไม่มีactualdeleteร้านจริงในการQA; demosหรือteststoreเท่านั้น
- [ ] RuninventoryDanger/dialogs/historyLayout; commit; G3

## Menu/Add-on management

