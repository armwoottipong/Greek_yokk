### Task 14: รับเข้า/ผลิต/ปรับยอด/ของเสียforms

**Files:** StockInModal.vue,StockAdjustModal.vue,WasteModal.vue,MaterialEditModal.vue; tests`stockFormInteraction.test.js`

- [ ] Testbase/packconversion, costpreview, receive/expiry, productionrecipe, lotselection, wastedqtyimpact, dirtycancel/validation
- [ ] DialogFrame/FormFieldจัดsectionsตามjob; เปลี่ยนunit/roleไม่resetdataนอกกฎเดิม; noanonymousinputs
- [ ] Errorโยงcontrolและnextaction; productioningredientsmissingไม่ให้saveผ่านเพราะUIhidefield
- [ ] Physicalkeyboard/safeareaและlongrecipeเป็นmanualgate; viewportifunsupportedต้องmarknotverified
- [ ] RunstockForms/materialEditing/requirements; commit

