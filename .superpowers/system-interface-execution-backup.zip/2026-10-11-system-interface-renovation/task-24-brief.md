### Task 24: Whole-systemfinishreview/QA/integration/deploy

**Files:** verificationreport/dateใหม่; fixproductfilesเฉพาะconfirmedfindings; noextraUIfeature

- [ ] Updateinventory36units: source/runtime/states/deviceevidence; ไม่มีblind“allclear”ที่unverified
- [ ] `npm test`, `npm run lint`, `npm run build`, `git diff --check` ผ่านบนfinalrevision
- [ ] Runimpeccabledetect**ครั้งเดียวหลังUIเสร็จ**; verifyfindingsincontextและไม่เปลี่ยนbrand/fontเพราะheuristicwarning
- [ ] Capturedesktop+iPadportrait/landscape+phone320/390ในbatchเดียว; initialstate/empty/error/dirty/loadingตามstateที่มีจริง; validcapturesไม่transitionframes
- [ ] ส่งfreshfinishreviewตามimpeccablereferenceพร้อมscope/files/PRODUCT/direction/screenshots/knownnotverified; อย่าให้reviewerรับframingจากtranscriptเต็ม
- [ ] Fixconfirmedmaterialfindingsหนึ่งbatch, rebuildและconfirmationcaptureหนึ่งbatch; ถ้ายังมีHIGH/qualitygateopenรายงานและอย่าประกาศApproved
- [ ] PhysicaliPad/Safari/keyboard/zoommanualgatesถ้าทำไม่ได้ระบุNotverifiedพร้อมstepsสำหรับuser ไม่ทำคะแนนเหมือนผ่าน
- [ ] เขียนDESIGN.md+`.impeccable/design.json`ตามdocumentworkflowให้ตรงสิ่งที่สร้างจริง ไม่ซ่อมconfigurationdriftนอกscope
- [ ] Integrationเข้mainตามauthorizationเดิม; stageเฉพาะtaskfiles; noforcepush/noeraseuserchanges; testอีกถ้าintegrationเปลี่ยนproductcode
- [ ] PushและตรวจBuild/PagesdeploymentของSHAนี้จนsuccess; smoke6routes+popupmainflowsด้วยtestorigin/data; ไม่ใช้realcheckoutหรือGASwrite
- [ ] Finalreport: F01–F13resolution, 24taskstatus, tests/limitations, SHA/versionURL, desktop/iPads/mobilecaptures; cleanupworktreeที่สร้างอย่างrecoverable

## Commit / implementation protocol

หลังG0ให้ใช้using-git-worktreesหาactiveworktreeที่เหมาะหรือสร้าง`codex/system-interface-renovation`; แต่ละtaskbehaviorใหม่เขียนfailingtest → verifyred → implement → verifygreen → relevantbrowsercheck → commit ไม่สร้างstyle-onlytestsที่ตรวจclassเดิมซ้ำ หลังtaskผ่านไม่รันtestทั้งหมดซ้ำหลายรอบโดยไม่มีchange/riskใหม่

อัปเดตcheckboxตามผลจริง: Taskที่state/devicegateยังไม่ผ่านต้องแยกdoneimplementationกับpendingverification ไม่ติ๊กครบเพื่อให้จำนวนงานสวย

## Definition of Done

- Desktop/iPadขายและจัดการครบ; phoneจัดการเร็วพร้อมdetailsเมื่อขอ
- F01–F06ไม่มีHIGHค้างและF07–F13มีdispositionชัด
- 36unitinventoryทุกแถวมีreviewstate/evidence; Notverifiedยังเปิดเผย
- Businessregressionsผ่าน, no duplicateorder/nodraftloss/noPOSplatformdrift
- Responsive/keyboard/motion/colorcontractsตรงDESIGNที่อนุมัติ
- Tests/lint/build/reviewer/deploymentผ่านตามscopeจริง ไม่ใช้buildsuccessแทนUIapproval

## Self-review

- [x] ขอบเขตครอบคลุมAppshell/6pages/14modalfiles/9ui/2graphs/2layout/2embeddedoverlays
- [x] Primarydevicesและmobilejobตรงคำตอบใหม่ของผู้ใช้
- [x] F01–F13mapไปtasksครบ; highissuesมาก่อนvisualpolish
- [x] Existingmascot/data/storebehaviorรักษาไว้; noauth/securityworkเพิ่ม
- [x] มีconfirmationgateสำหรับdesignใหม่และไม่ถือว่าoldplanapproved
- [x] บอกmissingbetter-*และmanualQAที่ยังไม่verified
- [x] ยังไม่มีproductUIchanges/deployในรอบauditนี้

