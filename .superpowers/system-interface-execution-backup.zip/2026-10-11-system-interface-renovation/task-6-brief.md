### Task 6: Select/checkbox/filter/calendar/emojiquality (F06/F09/F13)

**Files:** AppSelect.vue,AppCheckbox.vue,ToggleSwitch.vue,FilterDropdown.vue,DateRangeCalendar.vue,EmojiPickerPopover.vue; testsเพิ่มในexistingcontroltests

- [ ] Testcalendarordinarytextcontrastusingactualtokenvalues; Sunday≥4.5; dates/selectedrangehasnames
- [ ] Responsiveemoji5–6columnsและsearchname; fulllabeloftruncatedoptionsviewable; nohorizontalgridscroll
- [ ] Preservetypedselectvalues, keyboard/typeahead/disabled/draftfilterapply/cancel; datepickerไม่เพิ่มในcurrent-stockfilters
- [ ] Verifytouchtargetexceptionsชัด; nestedpickerไม่ปลดbackgroundlock/แย่งfocusจนinputใช้ไม่ได้
- [ ] Run`npx vitest run tests/ui/appSelect.test.js tests/ui/appCheckbox.test.js tests/ui/filterDropdown.test.js tests/ui/historyLayout.test.js`; browser320+iPad; commit

