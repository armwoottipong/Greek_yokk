### Task 23: Settings/backup/connection/categoryquality

**Files:** SettingsView.vue,settings.css; tests`settingsFormAccessibility.test.js`,existingsettingsNavigation

- [ ] คง4หมวดlayoutที่ดี; namedcategoryeditfields; labelofedit/deletebuttonsมีcontext
- [ ] Nativealert/confirmย้ายsharedconfirmationเฉพาะflowที่ได้behaviorparity; JSONimportvalidation/cancel/datareplacementเดิม
- [ ] URLsaved≠syncsuccess; idle/loading/error/retryมีstatusและnextactionจริง; ไม่syncร้านจริงเพื่อทดสอบUI
- [ ] Mobilebackup/importpriorities, advancedconnectiondetailsเข้าถึงได้; tabletsการ์ดไม่ถูกrailบีบ
- [ ] RunsettingsNavigation/data/replaceDatabase/GASmocktests; commit; G5

