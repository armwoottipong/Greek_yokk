### Task 22: Charts/tooltip/dataaccess

**Files:** DashboardTrend.vue,DashboardBreakdown.vue,ChartTooltip.vue,useChartTooltip.js; testsexistingchartTooltip/dashboardHoverเพิ่มsemanticscases

- [ ] Testindividual/groupclickonlymarkedarea, toggle/outside/Escape, pinnedhighlight/singledimming, arrowbounded, scrolllockrestore
- [ ] Interactivelegend/rankingnativebuttonsemantics; chartfallbacktable/labelsสำหรับnonvisualaccess
- [ ] Touchlargeenoughโดยไม่ทำblankplotคลิกได้; graphvisualdataheight/valuesไม่เปลี่ยนเพราะanimation
- [ ] Reducedmotion/nohoverpathและlossvalues/mobilelongrangesต้องทดสอบ
- [ ] RunchartTooltip/dashboardHover/dashboardTrend; commit

