### Task 13: Material/lot contextual detail

**Files:** StockView.vue; createStockMaterialCard.vue,MaterialDetails.vue,StockLotList.vue; tests`stockDetailPresentation.test.js`

- [ ] Testqtyzero/decimal/units/packcost, active/expired/receive-only/none, lotIDsถูก, archivedactions
- [ ] Viewmodelใช้existinghelpers/getMaterialLots/getExpiryStatus/getDraftDiffไม่เขียนstock/costformulaใหม่
- [ ] Desktop/tabletเปิดdetailpanelเมื่อพื้นที่พอ; mobiledetailsheet/card; openingdetailไม่switchlot
- [ ] Receiving/produce/actionlabelมีIDcontext; missing/deleteditemfallbackfocusไม่หลุด
- [ ] Runinventory/stockDetails; commit

