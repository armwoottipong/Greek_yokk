### Task 3: Button/IconButton/Status/typeและsemantictokens (F09/F12)

**Files:** create`Button.vue`,`IconButton.vue`,`StatusBadge.vue`ในui; modifymain.css/tailwind.config.jsและที่ใช้controls; tests`interfaceControls.test.js`

**Interface:** Button`{variant:'primary'|'secondary'|'quiet'|'danger',size:'compact'|'touch',loading,disabled}`; IconButtonต้อง`label`; StatusBadgeต้องtext ไม่ใช้สีอย่างเดียว

- [ ] Testdisabled/loadingไม่emitclick, namedicon, semanticstateยังเข้าใจเมื่อไม่มีสี
- [ ] ใช้aliasesจากexistingpalette; mapdimensions/hit-areaที่confirm ไม่globalreplaceทุกbutton
- [ ] Replacecontrolsในpriorityflowsก่อน; fontsdata/body/captionจากscale; remove!importantเฉพาะwhenreplacementtested
- [ ] ตรวจtouchbounds/keyboardfocus/contrastpairsบนnormal/selected/error ไม่ตีความdisabledเป็นcontrastfail
- [ ] Run`npx vitest run tests/ui/interfaceControls.test.js tests/ui/appCheckbox.test.js`; commit

