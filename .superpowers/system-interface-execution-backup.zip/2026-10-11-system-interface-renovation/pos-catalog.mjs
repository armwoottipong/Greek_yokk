import fs from 'node:fs'
let text=fs.readFileSync('src/views/PosView.vue','utf8').replace(/\r\n/g,'\n')
const left=text.indexOf('    <!-- Left: Menu Catalog Area -->'),right=text.indexOf('    <!-- Right: POS Order Cart Sidebar -->')
if(left<0||right<0)throw new Error('Catalog boundaries not found')
text=text.slice(0,left)+'    <PosCatalog :menus="filteredMenus" :platforms="store.platforms" :platform-id="store.currentPlatformId" v-model:search="searchQuery" v-model:category="activeCategory" :categories="categories" :price-for="getMenuPrice" :unavailable-for="isMenuOutOfStock" @platform="store.setPlatform($event)" @select-menu="selectMenu" />\n\n'+text.slice(right)
text=text.replace('class="h-[calc(100vh-8rem)] flex flex-col lg:flex-row gap-5 overflow-hidden"','ref="workspace" class="pos-workspace" :class="{\'is-split\':split}"')
text=text.replace('class="w-full lg:w-96 bg-white','class="pos-cart-legacy w-full lg:w-96 bg-white')
text=text.replace("import { Search, ShoppingBag, Check }","import { ShoppingBag, Check }")
text=text.replace("<script setup>","<script setup>\nimport PosCatalog from '@/components/pos/PosCatalog.vue'\nimport {useElementWidth} from '@/composables/useElementWidth'")
text=text.replace('const store = usePosStore()','const store = usePosStore()\nconst workspace=ref(null),width=useElementWidth(workspace)\nconst split=computed(()=>width.value>=696)\nfunction selectMenu(id){const menu=store.menus.find(m=>m.id===id);if(menu)handleMenuClick(menu)}')
text+=`
<style scoped>
.pos-workspace{display:flex;flex-direction:column;gap:16px;min-width:0}
.pos-workspace.is-split{flex-direction:row;height:calc(100dvh - var(--sidebar-header-height,var(--panel-header-height)) - 48px);min-height:480px;overflow:hidden}
.pos-workspace.is-split>.pos-cart-legacy{width:320px}
.pos-workspace.is-split :deep(.pos-catalog-scroll){overflow-y:auto;padding-right:2px;overscroll-behavior:contain}
</style>
`
fs.writeFileSync('src/views/PosView.vue',text)
