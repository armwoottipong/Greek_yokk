### Task 18: Menu/Addon listsและBOMreadflow

**Files:** MenuView.vue,AddonView.vue; createMenuCard.vue,AddonCard.vue,MenuRecipeDetails.vue; tests`catalogReadFlows.test.js`

- [ ] Testrecipe/edit/deleteemitexactID, missingmaterial/brokenlink/zeroamount, close/editrecipehandoff, no mutationonview
- [ ] ReplacelegacyBOMdialog, accessibleclose/title, cost/storeprice/margincopyที่ไม่ใช้GPกำกวม
- [ ] Mobilecards/tabletrowsอ่านชื่อและactionsได้; allplatformdetails/longnameมีexplicitdisclosure
- [ ] Formulaผลเดิมและzeroqtyไม่Inf; deletedselecteditemขณะpopupเปิดมีrecovery
- [ ] RuncatalogRead/priceForms/addons; commit

