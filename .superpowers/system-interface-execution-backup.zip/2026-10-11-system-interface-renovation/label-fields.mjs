import fs from 'node:fs'
import path from 'node:path'
const dirs=['src/components/modals','src/views']
const labels={'form.name':'ชื่อรายการ','form.category':'หมวดหมู่','form.description':'คำอธิบายเมนู','form.amountUsed':'ปริมาณวัตถุดิบต่อครั้ง','form.packUnit':'หน่วยสั่งซื้อ','form.packSize':'จำนวนหน่วยใช้ต่อแพ็ค','form.packCost':'ราคาซื้อต่อแพ็ค','form.yieldQty':'ปริมาณผลิตได้ต่อสูตร','form.shelfLifeDays':'อายุการเก็บรักษาเป็นวัน',inputPackQty:'จำนวนแพ็คที่รับเข้า',inputBaseQty:'จำนวนหน่วยที่รับเข้า',inputPackCost:'ราคาซื้อ',produceBatchCount:'จำนวนรอบผลิต',produceYieldQty:'จำนวนที่ต้องการผลิต',actualPackStock:'ยอดนับจริงเป็นแพ็ค',actualStock:'ยอดนับจริงเป็นหน่วยใช้',receiveDate:'วันที่รับเข้า',expiryDate:'วันหมดอายุ',note:'หมายเหตุ',wasteQty:'จำนวนที่ตัดทิ้ง',wasteNote:'หมายเหตุของเสีย','store.orderNote':'หมายเหตุออเดอร์','editCatForm.name':'ชื่อหมวดหมู่ที่แก้ไข','editCatForm.label':'ชื่อภาษาไทยของหมวดหมู่','newCatForm.name':'ชื่อหมวดหมู่ใหม่','newCatForm.label':'ชื่อภาษาไทยของหมวดหมู่ใหม่'}
for(const dir of dirs)for(const name of fs.readdirSync(dir).filter(n=>n.endsWith('.vue'))){
 const file=path.join(dir,name);let text=fs.readFileSync(file,'utf8')
 text=text.replace(/<(input|textarea)\b[^>]*>/g,tag=>{
  if(/aria-label(?:ledby)?\s*=/.test(tag)||/type="(?:file|checkbox|radio|hidden)"/.test(tag))return tag
  const model=tag.match(/v-model(?:\.[\w]+)*="([^"]+)"/)?.[1]
  let attr
  if(model==='form.prices[p.id]')attr=':aria-label="`ราคา ${p.name}`"'
  else if(model==='row.qty')attr=':aria-label="`ปริมาณ ${store.matMap[row.materialId]?.name || \'วัตถุดิบในสูตร\'}`"'
  else if(model==='searchQuery')attr='aria-label="'+(name.includes('Emoji')?'ค้นหาไอคอน':name.includes('Addon')?'ค้นหาท็อปปิ้ง':name.includes('Stock')?'ค้นหาวัตถุดิบ':'ค้นหาเมนู')+'"'
  else if(labels[model])attr='aria-label="'+labels[model]+'"'
  else if(tag.includes('displayStockPacks'))attr='aria-label="สต็อกปัจจุบันเป็นแพ็ค"'
  else if(tag.includes('displayMinAlertPacks'))attr='aria-label="ระดับเตือนสต็อกเป็นแพ็ค"'
  else return tag
  return tag.replace(/^<(input|textarea)/,'<$1 '+attr)
 })
 if(name==='MenuEditModal.vue'||name==='AddonEditModal.vue'){
  const field=name==='MenuEditModal.vue'?'ชื่อเมนู':'ชื่อท็อปปิ้ง';const id=name==='MenuEditModal.vue'?'menu-name':'addon-name'
  const re=name==='MenuEditModal.vue'?/<label\b[^>]*>\s*ชื่อเมนู[\s\S]*?<\/label>\s*(<input\b[^>]*\/\s*>)/:/<label\b[^>]*>\s*ชื่อ Add-on[\s\S]*?<\/label>\s*(<input\b[^>]*\/\s*>)/
  text=text.replace(re,(_,input)=>'<FormField id="'+id+'" label="'+field+'" required v-slot="{controlId,describedBy}">'+input.replace('<input','<input :id="controlId" :aria-describedby="describedBy"')+'</FormField>')
  text=text.replace('<script setup>','<script setup>\nimport FormField from \'@/components/ui/FormField.vue\'')
 }
 if(name==='MenuView.vue')text=text.replace('@click="closeBomModal"','aria-label="ปิดรายละเอียดสูตร" @click="closeBomModal"')
 if(name==='MaterialEditModal.vue')text=text.replace(/(@click="[^"]*(?:splice|remove)[^"]*"[^>]*?)aria-label="ปิดหน้าต่าง"/g,'$1aria-label="ลบวัตถุดิบจากสูตร"')
 fs.writeFileSync(file,text)
}
