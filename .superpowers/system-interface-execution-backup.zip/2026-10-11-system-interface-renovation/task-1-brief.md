### Task 1: ยืนยันdirectionและบันทึกcontractของทุกsurface

**Files:** PRODUCT.md; createDESIGN.md, `.impeccable/design.json`, surfacebriefsตามimpeccabledocument/new-workformat; audit/verificationdocs

**Input:** confirmeddevicejobsจากPRODUCT; auditF01–F13; selectedcompositionจากuser

**Output:** tokenbearingdesignrecord + surfacecontractsสำหรับ6routes/overlayfamilies ไม่ใช่prosepaletteเฉยๆ

- [ ] รับcompositionconfirmationผ่านstructuredquestion/decisionpageตามimpeccableshape/new-work; ไม่ถามbrandที่settledซ้ำ
- [ ] ระบุแต่ละsurfacejob, primaryaction, informationlevels, state/ranges และ anti-goals
- [ ] บันทึกแนวทางresponsive/selection/focus/danger/motionและcomponentownership
- [ ] Reviewcoverage36units; นำmissingbetter-*ไปcoveragegap ไม่อ้างholisticapproval
- [ ] เปิดdesignbriefและแสดงwireframeที่userตรวจได้; gateG0ผ่านก่อนproductedit

