import fs from 'node:fs'
function read(file){return fs.readFileSync(file,'utf8').replace(/\r\n/g,'\n')}
let side=read('src/components/layout/Sidebar.vue')
side=side.replace('<template>','<template>\n  <div v-if="isTablet && mobileOpen" class="sidebar-rail-placeholder" aria-hidden="true"></div>')
side=side.replace(":class=\"{'is-mobile-open':mobileOpen}\"",":class=\"{'is-mobile-open':mobileOpen,'is-tablet-rail':isTablet&&!mobileOpen}\"")
side=side.replaceAll("isMobile && mobileOpen?","isCompact && mobileOpen?")
side=side.replace(':key="item.id"',':key="item.id"\n        :aria-label="item.label + (item.badge ? \' \' + item.badge : \'\')" :title="item.label"')
side=side.replace("import { usePosStore }", "import {useMediaQuery} from '@/composables/useMediaQuery'\nimport {useOverlayScrollLock} from '@/composables/useOverlayScrollLock'\nimport { usePosStore }")
side=side.replace("const sidebar=ref(null),isMobile=ref(false)\nlet media","const sidebar=ref(null)\nconst isMobile=useMediaQuery('(max-width:767px)'),isCompact=useMediaQuery('(max-width:1199px)')\nconst isTablet=computed(()=>isCompact.value&&!isMobile.value)\nuseOverlayScrollLock(computed(()=>props.mobileOpen&&isCompact.value),sidebar)\nwatch(isCompact,value=>{if(!value)emit('close')})")
side=side.replace("function updateMobile(){isMobile.value=media.matches;if(!media.matches)emit('close')}\n",'')
side=side.replace('!isMobile.value)return','!isCompact.value)return')
side=side.replace("onMounted(()=>{media=window.matchMedia('(max-width:767px)');updateMobile();media.addEventListener('change',updateMobile);document.addEventListener('keydown',handleKeys)})","onMounted(()=>document.addEventListener('keydown',handleKeys))")
side=side.replace("onUnmounted(()=>{media?.removeEventListener('change',updateMobile);document.removeEventListener('keydown',handleKeys)})","onUnmounted(()=>document.removeEventListener('keydown',handleKeys))")
side=side.replace('</style>',`
.sidebar-rail-placeholder{width:72px;flex-shrink:0}
@media(min-width:768px) and (max-width:1199px){
 .brand-sidebar{width:72px}.brand-sidebar.is-tablet-rail .brand-navigation{padding:12px 8px}
 .brand-sidebar.is-tablet-rail .brand-nav-item{justify-content:center;padding:12px;width:56px}
 .brand-sidebar.is-tablet-rail .brand-nav-item>div>span,.brand-sidebar.is-tablet-rail .brand-nav-item>span,.brand-sidebar.is-tablet-rail>div:last-child{display:none}
 .brand-sidebar.is-mobile-open{position:fixed;inset:0 auto 0 0;width:min(300px,85vw);height:100dvh;z-index:60;box-shadow:12px 0 40px #58040618}
 .brand-sidebar.is-mobile-open .brand-navigation{display:block;flex:1;overflow-y:auto}.brand-sidebar.is-mobile-open .brand-nav-item{width:100%}
 .mobile-menu-backdrop{display:block;position:fixed;inset:0;background:#35252255;z-index:50}
}
</style>`)
fs.writeFileSync('src/components/layout/Sidebar.vue',side)
let original=read('src/components/layout/HeaderBar.vue')
let script=original.match(/<script setup>([\s\S]*?)<\/script>/)[1]
script=script.replace("import { RotateCcw, RefreshCw as CloudSync, Trash2, History }","import { RotateCcw, RefreshCw as CloudSync, Trash2, History,MoreHorizontal,Package }")
script=script.replace("const store = usePosStore()","import Button from '@/components/ui/Button.vue'\nimport DialogFrame from '@/components/ui/DialogFrame.vue'\n\nconst store = usePosStore()")
script=script.replace("defineEmits(['toggle-menu'])","const emit=defineEmits(['toggle-menu','request-close-navigation'])\nconst actionsOpen=ref(false),moreButton=ref(null)\nfunction openActions(){emit('request-close-navigation');actionsOpen.value=true}\nasync function runSystemAction(kind){actionsOpen.value=false;try{if(kind==='clear')await confirmClearAll();else if(kind==='demo')await confirmResetDemo();else await store.syncWithGas()}finally{await nextTick();moreButton.value?.focus()}}")
script=script.replace("watch(()=>props.mobileMenuOpen,async(open,previous)=>{if(!open && previous){await nextTick();menuToggle.value?.focus()}})","watch(()=>props.mobileMenuOpen,async(open,previous)=>{if(open)actionsOpen.value=false;if(!open&&previous){await nextTick();if(menuToggle.value&&getComputedStyle(menuToggle.value).display!=='none')menuToggle.value.focus();else document.querySelector('.brand-nav-item[aria-current=\"page\"]')?.focus()}})")
for(const [before,after] of [['ภาพรวมยอดขาย & งบต้นทุน','ภาพรวมร้าน'],['หน้าแคชเชียร์ขายหน้าร้าน (POS)','ขายหน้าร้าน'],['จัดการเมนู & สูตรวัตถุดิบ (Menu BOM)','เมนูและสูตร'],['จัดการ Add-on & ท็อปปิ้ง','ท็อปปิ้ง'],['คลังวัตถุดิบ & บรรจุภัณฑ์ (Raw Materials & BOM)','คลังวัตถุดิบ']])script=script.replace("title: '"+before+"'","title: '"+after+"'")
const template=`<template>
 <header ref="panelHeader" class="brand-page-header">
  <button id="mobile-menu-toggle" ref="menuToggle" type="button" class="mobile-menu-toggle" :class="{'is-open':mobileMenuOpen}" :aria-expanded="mobileMenuOpen" aria-controls="main-sidebar" :aria-label="mobileMenuOpen?'ปิดเมนูหลัก':'เปิดเมนูหลัก'" @click="$emit('toggle-menu')"><span></span><span></span><span></span></button>
  <div :inert="mobileMenuOpen" class="header-page-title"><h2>{{ pageTitle.title }}<small v-if="pageTitle.badge">{{ pageTitle.badge }}</small></h2><p>{{ pageTitle.subtitle }}</p></div>
  <div :inert="mobileMenuOpen" class="header-quick-actions">
   <Button v-if="store.lowStockMaterials.length" size="compact" variant="quiet" :aria-label="'วัตถุดิบใกล้หมด '+store.lowStockMaterials.length+' รายการ'" @click="store.switchTab('stock')"><Package :size="16" aria-hidden="true"/><span>{{ store.lowStockMaterials.length }}</span></Button>
   <Button size="compact" variant="quiet" aria-label="ประวัติกิจกรรม" @click="store.openActivityLog('all')"><History :size="17" aria-hidden="true"/><span class="header-action-label">ประวัติ</span></Button>
   <Button v-if="store.gasApiUrl" size="compact" variant="quiet" :loading="store.isSyncing" aria-label="สำรองข้อมูลไป Google Sheets" @click="store.syncWithGas()"><CloudSync :size="17" aria-hidden="true"/><span class="header-action-label">สำรองข้อมูล</span></Button>
   <button ref="moreButton" data-header-more class="header-more" type="button" aria-label="คำสั่งระบบเพิ่มเติม" aria-haspopup="dialog" :aria-expanded="actionsOpen" aria-controls="header-system-actions" @click="openActions"><MoreHorizontal :size="21" aria-hidden="true"/></button>
  </div>
 </header>
 <DialogFrame :open="actionsOpen" id="header-system-actions" title="คำสั่งระบบ" description="สำรองข้อมูล หรือเริ่มต้นข้อมูลร้านใหม่" presentation="sheet" @request-close="actionsOpen=false">
  <div class="header-system-actions">
   <Button variant="secondary" :disabled="!store.gasApiUrl||store.isSyncing" @click="runSystemAction('sync')"><CloudSync :size="18" aria-hidden="true"/>สำรองไป Google Sheets</Button>
   <p v-if="!store.gasApiUrl">เชื่อมต่อ Google Sheets ที่หน้าตั้งค่าก่อนสำรองออนไลน์</p>
   <Button variant="secondary" @click="store.switchTab('settings');actionsOpen=false">เปิดหน้าตั้งค่าและสำรองไฟล์</Button>
   <div class="header-action-divider"></div>
   <Button variant="quiet" @click="runSystemAction('demo')"><RotateCcw :size="18" aria-hidden="true"/>โหลดข้อมูลตัวอย่าง</Button>
   <Button variant="danger" @click="runSystemAction('clear')"><Trash2 :size="18" aria-hidden="true"/>ล้างข้อมูลทั้งหมด</Button>
   <p>การเริ่มข้อมูลใหม่จะแทนที่ข้อมูลปัจจุบัน และมีขั้นตอนยืนยันก่อนดำเนินการ</p>
  </div>
 </DialogFrame>
</template>`
const css=`<style scoped>
.brand-page-header{min-height:var(--panel-header-height);display:flex;align-items:center;justify-content:space-between;padding:16px 24px;gap:16px;border-bottom:1px solid var(--border-subtle);background:var(--bg-card);flex-shrink:0}
.header-page-title{min-width:0}.header-page-title h2{font-size:1rem;font-weight:600;line-height:1.5;letter-spacing:-.3px}.header-page-title p{font-size:.75rem;line-height:1.6;color:var(--text-muted);margin-top:3px}.header-page-title small{margin-left:8px}
.header-quick-actions{display:flex;align-items:center;gap:6px;flex-shrink:0}.header-more{display:grid;place-items:center;width:44px;height:44px;border-radius:10px;color:var(--accent-brand);background:transparent}.header-more:hover{background:var(--bg-soft)}
.header-system-actions{display:grid;gap:12px}.header-system-actions>.ui-button{justify-content:flex-start;text-align:left}.header-system-actions p{font-size:.75rem;color:var(--text-muted);line-height:1.7}.header-action-divider{height:1px;background:var(--border-subtle);margin:8px 0}
.mobile-menu-toggle{display:none;background:transparent;border:0;padding:11px;width:44px;height:44px;color:var(--accent-brand);cursor:pointer}
.mobile-menu-toggle span{display:block;width:22px;height:2px;background:currentColor;border-radius:2px;transform-origin:center}.mobile-menu-toggle span+span{margin-top:5px}
.mobile-menu-toggle.is-open span:first-child{transform:translateY(7px) rotate(45deg)}.mobile-menu-toggle.is-open span:nth-child(2){opacity:0;transform:scaleX(.3)}.mobile-menu-toggle.is-open span:last-child{transform:translateY(-7px) rotate(-45deg)}
.mobile-menu-toggle:focus-visible{outline:2px solid var(--accent-brand);outline-offset:2px}
@media(max-width:1199px){.brand-page-header{padding-left:66px}.mobile-menu-toggle{display:block;position:fixed;left:82px;top:12px;z-index:70}.mobile-menu-toggle.is-open{left:10px;color:var(--bg-card)}.header-action-label{display:none}}
@media(max-width:767px){.mobile-menu-toggle{left:10px}.brand-page-header{padding:12px 12px 12px 66px;gap:8px;align-items:center}.header-page-title h2{font-size:.875rem}.header-page-title p{display:none}.header-quick-actions{gap:0}.header-quick-actions>.ui-button{padding:10px;min-width:44px}}
@media(prefers-reduced-motion:no-preference){.mobile-menu-toggle span{transition:transform 200ms ease,opacity 140ms ease}}
</style>`
fs.writeFileSync('src/components/layout/HeaderBar.vue',template+'\n'+css+'\n<script setup>'+script+'</script>\n')
