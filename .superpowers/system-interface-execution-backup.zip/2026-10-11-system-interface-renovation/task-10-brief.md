### Task 10: CustomOrder และshortage/lotdecisionflow

**Files:** CustomOrderModal.vue,LowStockWarningModal.vue,LotDepletionModal.vue,PosView.vue; tests`posOverlayFlow.test.js`

- [ ] Testsameemojiaddonnames, checkboxstate, qtyname/units, shortagecancelคืนcustomordervalues, multiplelotsnext/cancel
- [ ] Touchselectaddonsและpinnedtotal/action; longwarnings/fulldataมีdisclosureที่มีcue
- [ ] Decisiondialogsใช้cancel-safeinitialfocusและcontext/impact; จำนวนที่ต้องใช้/มี/ขาดอ่านชัด
- [ ] เตรียมmulti-lotfixtureผ่านteststoreเพื่อruntimebranchที่auditยังไม่ได้ตรวจ; ห้ามderivebusinessdataจากvisualstate
- [ ] RunposOverlayFlow/dialogs/addons/inventorytests; commit

