from PIL import Image,ImageDraw
from pathlib import Path
root=Path('.impeccable/review')
for device in ['desktop','ipad-portrait','ipad-landscape','phone-390','phone-320']:
    sheet=Image.new('RGB',(1200,1000),'#e8dccb');draw=ImageDraw.Draw(sheet)
    for index,route in enumerate(['pos','stock','menu','addon','dashboard','settings']):
        im=Image.open(root/f'{device}-{route}.png').convert('RGB');size=im.size;im.thumbnail((390,450));x=(index%3)*400;y=(index//3)*500;draw.text((x+10,y+5),f'{device} {route} {size}',fill='#352522');sheet.paste(im,(x+5,y+30))
    sheet.save(root/f'contact-{device}.jpg')
