import fs from 'node:fs'
let text=fs.readFileSync('src/views/PosView.vue','utf8').replace(/\r\n/g,'\n')
const start=text.indexOf('    <!-- Right: POS Order Cart Sidebar -->'),end=text.indexOf('</template>')
if(start<0||end<0)throw new Error('Cart boundaries missing')
text=text.slice(0,start)+`    <CartPanel :presentation="split?'panel':'sheet'" :open="cartOpen" :checkout-pending="checkoutPending" @request-close="cartOpen=false" @checkout="handleCheckout" @switch-lot="handleSwitchLot"/>
    <CartReviewBar v-if="!split" :quantity="cartQuantity" :subtotal="Number(cartSummary.subtotal)" :open="cartOpen" @open="cartOpen=true"/>
  </div>
`+text.slice(end)
text=text.replace("import { ref, computed }","import { ref, computed,watch }")
text=text.replace("import { ShoppingBag, Check } from 'lucide-vue-next'","import CartPanel from '@/components/pos/CartPanel.vue'\nimport CartReviewBar from '@/components/pos/CartReviewBar.vue'")
text=text.replace("const split=computed(()=>width.value>=696)","const split=computed(()=>width.value>=696)\nconst cartOpen=ref(false),checkoutPending=ref(false)\nconst cartQuantity=computed(()=>store.cart.reduce((n,item)=>n+item.qty,0))\nwatch(split,value=>{if(value)cartOpen.value=false})")
text=text.replace("const paymentMethods = ['QR PromptPay', 'เงินสด', 'Platform Delivery']\n",'')
const helperStart=text.indexOf('function getAddonPrice('),helperEnd=text.indexOf('function isMenuOutOfStock(')
text=text.slice(0,helperStart)+text.slice(helperEnd)
text=text.replace('.pos-workspace.is-split>.pos-cart-legacy{width:320px}', '.pos-workspace:not(.is-split){padding-bottom:84px}')
fs.writeFileSync('src/views/PosView.vue',text)
