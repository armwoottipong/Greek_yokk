### Task 15: Stocktake และdraftreview

**Files:** StocktakeModal.vue,StockView.vue; createStockDraftReview.vue; tests`stocktakeDraftInteraction.test.js`

- [ ] Testcountbase/pack/onlydifferences/reset/variance/stagedraft; reviewcloseไม่commit/discard; filter/resize/navigationdraftคง
- [ ] คงStocktakeinputnamesและsummaryที่ดี; tabletใช้worksheetที่touchสะดวก; phonecompactrowsไม่table1120px
- [ ] Draftbar/statusบอก“ยังไม่บันทึก”, detailbefore/afterunits; commit/discardปุ่มไม่ถูกfooterอื่นบัง
- [ ] Testpersistence/recoveryและnoautocommit; compareledgeraftercommitกับbaseline
- [ ] Rundrafts/recoveryEdges/stocktakeLayout; commit

