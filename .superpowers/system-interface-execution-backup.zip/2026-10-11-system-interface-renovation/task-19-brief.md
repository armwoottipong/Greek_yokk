### Task 19: Menu editor

**Files:** MenuEditModal.vue; optionaldomainfieldgroupsใต้components/menu; tests`menuEditorInteraction.test.js`

- [ ] Testcollapsedsectionskeepdraft, namedprices/qty, erroropenrelevantsection, dirtypromptcancel, savepayloadunchanged
- [ ] Sectionsname/category/prices/recipe/package/permissions; tabletformใช้พื้นที่ได้phoneonecolumn; footerCTAเข้าถึงเมื่อkeyboardเปิด
- [ ] Recipe30rows/longnamesต้องเลื่อนในbodyไม่ทั้งdialog; rowremoveชื่อcontextถูก
- [ ] ใช้sharedFormField/AppSelect/AppCheckbox/DialogFrame ไม่สร้างcheckboxthemeใหม่
- [ ] RunmenuEditor/priceForms/requirements; commit

