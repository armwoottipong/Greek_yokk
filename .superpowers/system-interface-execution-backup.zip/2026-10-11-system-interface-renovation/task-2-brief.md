### Task 2: FormFieldและaccessible-namecoverage (F01/F02)

**Files:** create`src/components/ui/FormField.vue`; modifyformcomponentsและsearchfieldsในviews; create`tests/ui/formField.test.js`, `tests/ui/interfaceNames.test.js`

**Interface:** props`{id,label,required,hint,error}`; slot`{controlId,describedBy,invalid}`; ownerinputรับid/aria-describedby/aria-invalid; icon-onlynameผ่านexplicitlabel

- [ ] Testlabel↔id, hint/errorassociation, requiredannouncement; fixturesราคาหลายplatformและqtyหลายrecipeต้องมีชื่อไม่ซ้ำ
- [ ] Runfailingtestsก่อนimplement; confirmfailureมาจากmissinginterface ไม่ใช่fixtureผิด
- [ ] ย้ายfieldlabelpatternsทีละfamily; เพิ่มBOMclose “ปิดรายละเอียดสูตร”; Materialrecipe-removeใช้ “ลบวัตถุดิบจากสูตร”
- [ ] Run`npx vitest run tests/ui/formField.test.js tests/ui/interfaceNames.test.js tests/ui/priceForms.test.js tests/ui/stockForms.test.js`
- [ ] BrowserAXตรวจไม่เหลือanonymousprice/qtycontrolsในopenedforms; preservepayload/validation; commit

