### Task 4: DialogFrame/layer/focus/scrollร่วม (F03)

**Files:** modify`ModalShell.vue`; create`DialogFrame.vue`,`useOverlayScrollLock.js`; migrateembeddedBOM/delete; tests`dialogLayers.test.js`,existingdialogs

**Interface:** DialogFrame`{open,id,title,presentation:'dialog'|'sheet'|'panel',busy}`; emits`request-close`; slotsheader/body/footer; ModalShellยังเป็นfocus/inertstackเจ้าของเดียว

- [ ] Testtoplayeronly, Tab/Escape/restorefocus, openerdeletedfallback, scrollbodyได้backgroundไม่ได้, nestedlocksreleaseถูกลำดับ
- [ ] Implementlease-countscrolllockและownerlayerregistry; AppSelectportedlistต้องอยู่effectiveownerlayerเหนือdialog ไม่ใช้9999/10000แข่ง
- [ ] Responsiveheight100dvh/visualViewportเมื่อจำเป็น; header/footerไม่ตัด; preservecontent/lockระหว่างleave
- [ ] MigratelegacyoverlaysและDialogFramefamilyก่อนปรับหน้าตาแต่ละpopup; คงconfirmcallbacks/dirtyguard
- [ ] Run`npx vitest run tests/ui/dialogs.test.js tests/ui/dialogLayers.test.js tests/ui/chartTooltip.test.js`; verifyDOMbackgroundisolated; commit

