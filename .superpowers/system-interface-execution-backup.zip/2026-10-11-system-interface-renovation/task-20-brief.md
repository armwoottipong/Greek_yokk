### Task 20: Add-on editor/linkage

**Files:** AddonEditModal.vue; tests`addonEditorInteraction.test.js`

- [ ] Testprices0/missing, amountUsed0/decimal, materialchangeunit, unlinked/missingreference, dirtycancel/savepayload
- [ ] Layoutheader/body/footerและnamedfields; priceplatformnameเต็มอ่านได้บนphoneและtablet
- [ ] Linkagegroupบอกตัดต่อครั้งพร้อมunit; validation/recoveryตรงstore ไม่สร้างmatอัตโนมัติ
- [ ] Phonekeyboardlastprice/qtyแล้วsaveได้; noamountfallback1โดยเผลอ
- [ ] RunaddonEditor/priceForms/addons; commit; G4

## Dashboard / Settings

