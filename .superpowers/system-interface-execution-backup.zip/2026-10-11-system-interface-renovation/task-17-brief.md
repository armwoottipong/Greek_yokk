### Task 17: Shared catalog filters/pricecontexts (F08/F11)

**Files:** MenuView.vue,AddonView.vue; createCatalogToolbar.vue,PlatformPriceSummary.vue; tests`catalogPriceContext.test.js`

**Interface:** displayPlatformIdเป็นlocalviewstate; toolbaremitsapplyfilters/search/add; pricepresentationzero/missing/unknownplatformต่างกัน

- [ ] Testdisplayplatformไม่เรียกsetPlatform, price0, missingprices, platformremovedfallback, unknowncategories
- [ ] Desktopmultichannel/tabledetails; tabletessentialcolumnsและpricecontext; phonecardราคาเดียว+รายละเอียดทั้งหมด
- [ ] Searchplaceholderตรงfiltername/descriptionเดิม ไม่แอบเพิ่มBOMsearchในการUIrefactor
- [ ] Apply/cancel/resetdraftfiltersและempty/noresultCTA; sharepartsไม่รวมstoreactionsในgenericcomponent
- [ ] RuncatalogPrice/priceForms; commit

