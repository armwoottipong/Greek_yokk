### Task 21: Dashboard adaptive informationhierarchy

**Files:** DashboardView.vue,dashboard.css; tests`dashboardDevicePresentation.test.js`

- [ ] Test4views/datepresets/customrange/zeroorders/negativeprofit; samefinancialsnapshotsacrossdevices
- [ ] Desktopcomparativepanels, tabletchartsตามcontainer, phonekeynumbersfirst; receiptlistcompactแทนwidebilltableบนphone
- [ ] Advanceddataเข้าถึงผ่านdetailsไม่ถูกลบทิ้ง; captions/GP/marginclear; don'tinventforecastหรือnewreport
- [ ] PreserveBangkokbusinessdate/recordedcostscope; missinginputerrorใช้existinghelpers
- [ ] Rundashboard/reportssuites; commit

