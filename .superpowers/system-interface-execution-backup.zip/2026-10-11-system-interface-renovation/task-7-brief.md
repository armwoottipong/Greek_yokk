### Task 7: App shell/header/sidebarสามdeviceclasses (F04/F07)

**Files:** App.vue,HeaderBar.vue,Sidebar.vue; create`useMediaQuery.js`ถ้ายังไม่มี; tests`adaptiveShell.test.js`, existingmobileNavigation/headerSizing

- [ ] Testfull/rail/drawerbreakpointsที่confirmed, focusreturn, drawerกับmoremenuไม่เปิดพร้อมกัน, routechangecloseแต่businessstateไม่reset
- [ ] คงhamburgerไม่มีพื้นหลังและiconanimation; fullmascotasset90%right-bottom/#5E0205ตามผู้ใช้เดิม
- [ ] Titleหนึ่งแห่ง/count/contextชัด; globallydestructiveactionsไปsettingsหรือmoremenu พร้อมconfirmationเดิม
- [ ] ตรวจ768/834/1024/1194/1280/320และrotation; URL/deeplink/KeepAliveทำงานเหมือนเดิม
- [ ] Run`npx vitest run tests/ui/adaptiveShell.test.js tests/ui/mobileNavigation.test.js tests/ui/headerSizing.test.js`; commit; G1review

## POS — เครื่องหลักหน้าร้านก่อนมือถือ

