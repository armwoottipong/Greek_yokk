### Task 11: Checkout/receipt/printส่งมอบflow

**Files:** PosView.vue,CartPanel.vue,ReceiptModal.vue; tests`checkoutInteraction.test.js`,existingcheckout/shortageReceipt

- [ ] Testdoubletap/shortageconfirmationretry/ordercount1, cancelretaincart, errorretaininputs; callbacksเดิมretryallowShortageไม่ถูกlockทิ้ง
- [ ] ตรวจreceiptopenafteractualsuccessและclosecartonlywhencompleted; nofalse“สำเร็จ”หลังstore returnnullรอconfirm
- [ ] Receiptread/print80mmแยกvisualstyles; reducedmotionจากtask5; historyviewไม่เล่นconfetti
- [ ] Manualcheckoutเฉพาะisolateddemo; comparestockallocation/order totals/receiptและhistory
- [ ] RunPOS/inventorysuite; screenshotdevicebatch; commit; G2

## Stock — ทุกflowของคลัง

