### Task 5: Feedback/motion/recoveryและreceiptconfetti (F05/F10)

**Files:** ToastContainer.vue,ReceiptModal.vue,feedbackstyles; tests`feedbackAccessibility.test.js`,`receiptMotion.test.js`

- [ ] MockmatchMediareduce=true → confetticalls0หรือdisableForReducedMotion=true; false → optionalsalessuccessหนึ่งครั้ง ไม่historyreopen
- [ ] Addstatus/alertliveannouncements, mobiletoastwidthmargin16, recoverytextสำหรับerrors; nofocussteal
- [ ] Sourceerrorcopyต้องมีactionตามจริง ไม่แต่งstatus“เชื่อมต่อสำเร็จ”จากการsaveURL
- [ ] Run`npx vitest run tests/ui/feedbackAccessibility.test.js tests/ui/receiptMotion.test.js tests/ui/shortageReceipt.test.js`
- [ ] Confirmreducedmotionactualemulationถ้าtoolรองรับ; otherwiseexplicitmanualgate; commit

